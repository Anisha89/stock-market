package in.ksix.smda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SmdaTests {

	@Test
	public void contextLoads() {
	}

}
