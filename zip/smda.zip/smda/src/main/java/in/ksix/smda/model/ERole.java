package in.ksix.smda.model;

public enum ERole {
  ROLE_USER, //0 
  ROLE_ADMIN, //1
  ROLE_MODERATOR,//2
}
